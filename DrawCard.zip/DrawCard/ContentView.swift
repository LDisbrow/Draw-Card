//
//  ContentView.swift
//  DrawCard
//
//  Created by Luca Disbrow on 8/8/21.
//  Copyright © 2021 Luca Disbrow. All rights reserved.
//

import SwiftUI

//public var numArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
//                       11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
//                       21, 22, 23, 24, 25, 26, 27]

struct ContentView: View {
    
    @State private var randNum = 0
    @State private var numArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
                                   21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33,
                                   41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53,
                                   61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73]
    
    var body: some View {
        ZStack {
            LinearGradient(gradient: Gradient(colors: [.purple, .red]),
                startPoint:.topLeading,
                endPoint: .bottomTrailing)
                .edgesIgnoringSafeArea(.all)
            VStack{
                //Text("Deck of Cards")
                    //.font(.system(size: 25, weight: .medium, design: .default))
                    //.foregroundColor(.white)
                    //.padding()
                
                VStack {
                    Image("card" + String(randNum))
                        .renderingMode(.original)
                        .resizable()
                        .frame(width: 300, height: 450)
                }
                
                Spacer()
                
                HStack{
                    
                    Spacer()
                    
                    VStack{
                        Button(action: {
                            
                            //select new card
                            if( self.numArray.count == 0)
                            {
                                //reset card, array is empty
                                self.randNum = 0
                            }
                            else{
                                //initialize variables
                                let value = self.numArray.randomElement()!
                                self.randNum = value
                                var index = 0;
                                
                                while(self.numArray[index] != value) {
                                    index += 1
                                }
                                
                                self.numArray.remove(at: index)
                            }
                            // implement for loop with if statement to make sure same card isn't pulled twice
                            
                            
                            print("Button Pressed")
                        }) {
                            Text("New Card")
                                .font(.system(size:21, weight: .bold, design: .default))
                                .foregroundColor(.white)
                                .padding(10.0)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10.0)
                                        .stroke(lineWidth:2.0)
                                        .foregroundColor(.white))
                        }
                    }
                     
                    Spacer()
                    
                }
                
                //Spacer()
                
                HStack{
                    VStack{
                        Text("Cards Left: " + String(self.numArray.count))
                        .font(.system(size: 15, weight: .medium, design: .default))
                        .foregroundColor(.white)
                        .padding()
                    }.padding()
                    
                    Spacer()
                    
                    
                    VStack{
                        Button(action: {
                            self.randNum = 0
                            self.numArray = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13,
                            21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33,
                            41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53,
                            61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73]
                            print("Button Pressed")
                        }) {
                            Text("Reset")
                                .font(.system(size:15, weight: .bold, design: .default))
                                .foregroundColor(.white)
                                .padding(10.0)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10.0)
                                        .stroke(lineWidth:2.0)
                                        .foregroundColor(.white))
                        }
                    }.padding()
                    
                }
            
                
                //Spacer()
                /*
                Button(action: {
                    
                    print("night mode pressed")
                }) {
                    Text("Night Mode")
                        .font(.system(size:15, weight: .bold, design: .default))
                        .foregroundColor(.white)
                        .padding(10.0)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10.0)
                                .stroke(lineWidth:2.0)
                                .foregroundColor(.white))
                }
                
                Spacer()
                */
            }
            
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


